create function bit_length(bit) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.length($1)
$$;
